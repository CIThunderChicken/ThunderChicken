# Description

The ADForestProperties DSC resource will manage User Principal Name (UPN) suffixes and Service Principal Name (SPN) suffixes in a forest.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
